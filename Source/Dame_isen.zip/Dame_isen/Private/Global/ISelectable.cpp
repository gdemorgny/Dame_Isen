// Fill out your copyright notice in the Description page of Project Settings.


#include "Global/ISelectable.h"

// Add default functionality here for any IISelectable functions that are not pure virtual.

void IISelectable::Select()
{
}

void IISelectable::Unselect()
{
}
