// Fill out your copyright notice in the Description page of Project Settings.


#include "GamePlay/DamePion.h"

#include "GamePlay/DameCase.h"
#include "Slate/SGameLayerManager.h"

// Sets default values
ADamePion::ADamePion()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}


void ADamePion::Die()
{
	for(int i =0;i<Board->DameGM->PlayerPawns[(-PlayerId == 1)?0:1].Pawns.Num();i++)
	{
		if(Board->DameGM->PlayerPawns[(-PlayerId == 1)?0:1].Pawns[i] == this)
		{
			Board->DameGM->PlayerPawns[(-PlayerId == 1)?0:1].Pawns.RemoveAt(i);
		}
	}
	Destroy();
}

void ADamePion::BecameAQueen()
{
}

// Called when the game starts or when spawned
void ADamePion::BeginPlay()
{
	Super::BeginPlay();
	
}

void ADamePion::Select()
{
	if(Board->DameGM->ActualPlayer == PlayerId)
	{
		ChangeMaterial(true);
		//TODO : Informer le board qu'un pion est sélectionné et qu'il doit déterminer les chemins possibles.
		Board->NewPawnSelect(this);
	}
	
	
}

void ADamePion::Unselect()
{
	for(int i=0;i<Board->CellValidMoves.Num();i++)
	{
		Board->CellHighlight(Board->CellValidMoves[i].Cells.Last());
	}
	
	ChangeMaterial(false);
}

void ADamePion::StartMoveSequence(const TArray<FVector>& InMoveSequence, TArray<ADamePion*> InOpponentToDestroy)
{
	if (InMoveSequence.Num() == 0) return; // S'assurer qu'il y a une séquence

	MoveSequence = InMoveSequence;
	OpponentsToDestroy = InOpponentToDestroy;
	
	

	// Initialisation des positions pour le premier mouvement
	MoveProgress = 0.0f;
	StartPosition = GetActorLocation();
	TargetPosition = MoveSequence[0];
	MoveSequence.RemoveAt(0);

	// Lancer le premier déplacement
	MoveToNextPosition();
}

void ADamePion::MoveToNextPosition()
{
	// Assurer que le timer est bien réinitialisé
	GetWorldTimerManager().ClearTimer(MovementTimer);
	MoveProgress = 0.0f;

	// Utilisation d'un Timer pour déclencher le mouvement chaque 0,5s
	GetWorldTimerManager().SetTimer(MovementTimer, this, &ADamePion::OnMoveCompleted, 0.5f, false);

	// Déclencher le mouvement visuel
	FVector NewLocation = CalculateArcPosition(MoveProgress);
	SetActorLocation(NewLocation);

	// Incrémenter la progression
	MoveProgress += 0.05f;
}

void ADamePion::OnMoveCompleted()
{
	// Mettre à jour la position finale du mouvement
	SetActorLocation(TargetPosition);
	UE_LOG(LogTemp, Display, TEXT("OnMoveCompleted"));
	if (OpponentsToDestroy.Num() > 0)
	{
		// Destruction du pion adverse
		if(OpponentsToDestroy[0] != nullptr)
		{
			Board->Cells[OpponentsToDestroy[0]->CellNumber]->PawnInCell = nullptr;
		}
		
		Board->UpdatePlayerValueInCell(OpponentsToDestroy[0]->CellNumber);
		FString NewPlayerName = OpponentsToDestroy[0]->GetName();
		UE_LOG(LogTemp, Display, TEXT("OpponentDestroyed %s"),*NewPlayerName);
		OpponentsToDestroy[0]->Die();
		OpponentsToDestroy.RemoveAt(0);
	}

	if (MoveSequence.Num() > 0)
	{
		// Reconfigurer le mouvement pour la prochaine case dans la séquence
		StartPosition = TargetPosition;
		TargetPosition = MoveSequence[0];
		MoveSequence.RemoveAt(0);
		MoveToNextPosition(); // Appeler la prochaine séquence
	}
	else
	{
		// Séquence terminée
		GetWorldTimerManager().ClearTimer(MovementTimer);
		ChangeMaterial(false);
		Board->DameGM->ChangePlayer();
	}
}

FVector ADamePion::CalculateArcPosition(float LerpValue) const
{
	// Calculer une position interpolée entre StartPosition et TargetPosition
	FVector MidPoint = (StartPosition + TargetPosition) * 0.5f;
	MidPoint.Z += 100; // Élever le point intermédiaire pour former un arc

	// Interpolation quadratique pour simuler un arc en forme de cloche
	FVector FirstLerp = FMath::Lerp(StartPosition, MidPoint, LerpValue);
	FVector SecondLerp = FMath::Lerp(MidPoint, TargetPosition, LerpValue);
	return FMath::Lerp(FirstLerp, SecondLerp, LerpValue);
}

void ADamePion::ChangeMaterial(bool isHightlightActive = false)
{
	if(isHightlightActive)
	{
		StaticMesh->SetMaterial(0,HighlightMaterial);
	} else if(PlayerId == 1)
	{
		StaticMesh->SetMaterial(0,FirstPlayerMaterial);
	} else
	{
		StaticMesh->SetMaterial(0,SecondPlayerMaterial);
	}
}

// Called every frame
void ADamePion::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

