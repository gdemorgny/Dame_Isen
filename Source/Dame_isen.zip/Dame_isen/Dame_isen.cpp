// Copyright Epic Games, Inc. All Rights Reserved.

#include "Dame_isen.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Dame_isen, "Dame_isen" );
